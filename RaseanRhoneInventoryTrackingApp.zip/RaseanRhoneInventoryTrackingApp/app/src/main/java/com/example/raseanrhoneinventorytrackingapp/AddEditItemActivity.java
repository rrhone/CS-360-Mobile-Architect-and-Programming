package com.example.raseanrhoneinventorytrackingapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.example.raseanrhoneinventorytrackingapp.dao.ItemDao;
import com.example.raseanrhoneinventorytrackingapp.data.Item;

public class AddEditItemActivity extends AppCompatActivity {
    private EditText itemNameEditText; // EditText for item name
    private EditText itemQuantityEditText; // EditText for item quantity
    private ItemDao inventoryItemDao; // DAO for inventory item operations

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_item);

        // Initialize views
        itemNameEditText = findViewById(R.id.itemName);
        itemQuantityEditText = findViewById(R.id.itemQuantity);
        // Button to save item details
        Button saveButton = findViewById(R.id.saveButton);

        // Initialize the database and DAO
        AppDatabase db = AppDatabase.getDatabase(this);
        inventoryItemDao = db.inventoryItemDao();

        // Set click listener for save button
        saveButton.setOnClickListener(v -> saveItem());
    }

    // Save new or edited item
    private void saveItem() {
        String itemName = itemNameEditText.getText().toString();
        int itemQuantity = Integer.parseInt(itemQuantityEditText.getText().toString());

        // Create a new inventory item and insert into the database
        Item item = new Item(itemName, itemQuantity);
        inventoryItemDao.insert(item);

        // Close the activity and return to the previous screen
        finish();
    }
}