package com.example.raseanrhoneinventorytrackingapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.raseanrhoneinventorytrackingapp.dao.UserDao;
import com.example.raseanrhoneinventorytrackingapp.data.User;

public class MainActivity extends AppCompatActivity {
    private EditText usernameEditText; // EditText for username input
    private EditText passwordEditText; // EditText for password input
    private UserDao userDao; // DAO for user operations

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        usernameEditText = findViewById(R.id.username);
        passwordEditText = findViewById(R.id.password);
        // Button for login action
        Button loginButton = findViewById(R.id.loginButton);
        // Button for registration action
        Button registerButton = findViewById(R.id.registerButton);

        // Initialize the database and DAO
        AppDatabase db = AppDatabase.getDatabase(this);
        userDao = db.userDao();

        // Set click listeners for buttons
        loginButton.setOnClickListener(v -> login());
        registerButton.setOnClickListener(v -> register());
    }

    // Handle user login
    private void login() {
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        // Check credentials against the database
        User user = userDao.login(username, password);
        if (user != null) {
            // Navigate to inventory activity if login is successful
            Intent intent = new Intent(this, InventoryActivity.class);
            startActivity(intent);
        } else {
            // Show error message if login fails
            Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show();
        }
    }

    // Handle user registration
    private void register() {
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        // Create a new user and insert into the database
        User user = new User(username, password);
        userDao.insert(user);
        Toast.makeText(this, "User registered successfully", Toast.LENGTH_SHORT).show();
    }
}