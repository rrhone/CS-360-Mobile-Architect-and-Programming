package com.example.raseanrhoneinventorytrackingapp.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.raseanrhoneinventorytrackingapp.R;
import com.example.raseanrhoneinventorytrackingapp.data.Item;

import java.util.List;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {
    private List<Item> itemList; // List of inventory items

    public InventoryAdapter(List<Item> itemList) {
        this.itemList = itemList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate item view for RecyclerView
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.activity_inventory, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // Bind data to ViewHolder
        Item item = itemList.get(position);
        holder.itemName.setText(item.getName());
        holder.itemQuantity.setText(String.valueOf(item.getQuantity()));

        holder.deleteButton.setOnClickListener(v -> {
            item.delete(item); // Delete item from the database
            itemList.remove(position); // Remove item from the list
            notifyItemRemoved(position); // Notify adapter about item removal
        });
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView itemName; // TextView for item name
        TextView itemQuantity; // TextView for item quantity
        Button deleteButton; // Button to delete item

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            itemName = itemView.findViewById(R.id.itemName);
            itemQuantity = itemView.findViewById(R.id.itemQuantity);
            deleteButton = itemView.findViewById(R.id.deleteButton); // Initialize delete button
        }
    }
}