package com.example.raseanrhoneinventorytrackingapp;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.raseanrhoneinventorytrackingapp.adapters.InventoryAdapter;
import com.example.raseanrhoneinventorytrackingapp.dao.ItemDao;
import com.example.raseanrhoneinventorytrackingapp.data.Item;

import java.util.List;

public class InventoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        // Initialize RecyclerView and set layout manager
        // RecyclerView for displaying inventory items
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialize the database and DAO
        AppDatabase db = AppDatabase.getDatabase(this);
        // DAO for inventory item operations
        ItemDao inventoryItemDao = db.inventoryItemDao();

        // Fetch inventory items and set up adapter
        List<Item> itemList = inventoryItemDao.getAllItems();
        // Adapter for binding data to RecyclerView
        InventoryAdapter inventoryAdapter = new InventoryAdapter(itemList);
        recyclerView.setAdapter(inventoryAdapter);

        // Set click listener for add item button
        Button addItemButton = findViewById(R.id.addItemButton);
        addItemButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, AddEditItemActivity.class);
            startActivity(intent);
        });

        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) Button deleteButton = findViewById(R.id.deleteButton); // Ensure you have this button in your layout
        deleteButton.setOnClickListener(v -> {
            // Assuming you have a way to get the item to delete, e.g., from a list or passed to the activity
            Item itemToDelete = itemToDelete(); // Replace with actual item retrieval logic
            if (itemToDelete != null) {
                Toast.makeText(this, "Item has been deleted", Toast.LENGTH_SHORT).show();
            } else {
                // Handle the case where itemToDelete is null
                Toast.makeText(this, "No item selected for deletion", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private Item itemToDelete() {
        return null;
    }
}